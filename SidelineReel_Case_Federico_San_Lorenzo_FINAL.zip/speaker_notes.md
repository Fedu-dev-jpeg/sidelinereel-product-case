# SidelineReel — Short Speaker Notes

**Goal:** 5–7 minutes.  
**Rule:** Don’t read. Use these as prompts.

## 1) Start — Markdown / Executive Summary
**SHOW:** `sidelinereel_case.md` → Executive Summary

**SAY:**  
“The core product already works when parents trust it: 92% of opened reels are shared. The bigger issue is that around 30% are never opened, and the evidence points to late notifications and wrong-player thumbnails. I prioritize trust first.”

## 2) Roadmap
**SHOW:** Task 1 ranking

**SAY:**  
“My order is: 1) Player Identity Confidence Gate, 2) notification timing, 3) urgent Ridgeline livestreaming discovery/pilot, 4) investigate Reel Editor abandonment, then smaller defects.”

**SHOW:** “What I would NOT build next”

**SAY:**  
“I would not commit to full livestreaming as the next major build. Ridgeline is a $180k account, so I’d give Carla a concrete pilot/feasibility answer quickly, but I would not rush a large new system while the core product still has a trust defect.”

## 3) Spec
**SHOW:** Task 2 → Desired outcome / In scope / Human in the loop

**SAY:**  
“The gate gives every candidate clip an identity-confidence score. High confidence flows automatically. Low confidence is blocked. A human only reviews ambiguity and can confirm, reassign, or exclude.”

**SHOW:** Acceptance criteria + failure modes

**SAY:**  
“An unresolved clip can never publish, and thumbnails only use verified clips. The two risks are an overconfident model that lets bad clips through, or too many flags creating review fatigue.”

## 4) Product demo
**SWITCH TO:** `sidelinereel_prototype.html`

### Dashboard
**SAY:**  
“This is the normal product. Every player has a generated example reel.”

**CLICK:** `View example reel` on **Lucas #7**  
**CLICK:** `Play reel` for a few seconds  
**SAY:** “This is a healthy case: all clips are high-confidence, so there is no human step.”  
**CLICK:** `×`

### Problem case
**CLICK:** `Preview draft reel` on **Maya #14**  
**CLICK:** `Next clip` until you reach a blocked clip  
**SAY:** “Maya’s reel is generated too, but uncertain clips are visibly blocked instead of silently publishing.”  
**CLICK:** `×`

**CLICK:** `Review identity`

### Review flow
**CLICK:** `Start identity review`  
**SAY:** “The reviewer sees only the ambiguous clips, not the entire reel.”

**CLICK:** `Confirm suggested` on Clip B  
**CLICK:** `Exclude` or `Reassign` on Clip D

**SAY:** “Once ambiguity is resolved, the reel becomes safe to publish.”

**CLICK:** `Preview final reel`  
**CLICK:** `Play reel` briefly  
**SAY:** “The final reel contains verified content only.”  
**CLICK:** `×`

**CLICK:** `Publish reel`

## 5) AI workflow
**SWITCH BACK:** Markdown → Task 4

**SAY:**  
“I used AI to organize evidence, pressure-test prioritization, draft acceptance criteria, and accelerate the prototype. I kept prioritization and product trade-offs human. One thing I rejected was taking the 58% editor survey result at face value because actual editor usage is extremely low.”

## 6) Close — camera
**SAY:**  
“I’m Federico San Lorenzo, a software developer and technical project professional from Argentina. I like problems where product judgment, business constraints, and technical execution meet. That’s why this role and Ajaia are interesting to me. My compensation expectation is **USD 45,000 gross annually**, depending on scope and total package. Thank you.”
